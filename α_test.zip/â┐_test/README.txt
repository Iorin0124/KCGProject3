α_test
	css
		3dmodels-list-pc.css	//3Dモデル一覧表示のCSS(主に横画面)
		3dmodels-list-sp.css	//3Dモデル一覧表示のCSS(主に縦画面)
		drawer.min.css	//ドロワーメニューのCSS
		drawing-pc.css	//３Dモデル表示画面のCSS(主に横画面)
		drawing-sp.css	//３Dモデル表示画面のCSS(主に縦画面)
		index-pc.css	//TopページのCSS(主に横画面)
		index-sp.css	//TopページのCSS(主に縦画面)
	images
		各所で使用している画像
	js
		drawer.min.js	//ドロワーメニューのプラグイン
		iscroll.js	//ドロワーメニューに使用しているjs
		jquery-3.1.1.min.js	//jQuery
		OrbitControls.js	//three.jsのプラグイン
		TDSLoader.js	//three.jsのプラグイン
		three.min.js	//webGLを拡張するプラグイン
	models
		オブジェクト形式の3Dモデル（ダミーデータ）
	textures
		3dmodels-list.html	//3Dモデル一覧表示
		camera.html	//カメラ撮影画面
		demo-pc.html	//３Dモデル表示画面(自分のPCでのダミーデータ)
		index.html	//Topページ
		sample01.html	//基本の立方体のモデル
		sample02.html	//オブジェクト形式の3Dモデルを読み込んでの描画テスト
	